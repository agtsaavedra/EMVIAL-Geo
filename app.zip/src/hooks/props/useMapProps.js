import { useMemo } from 'react'

export function useMapProps({
  form,
  setForm,

  intervencionesFiltradas,
  intervencionEditandoId,

  puntoSeleccionado,
  setPuntoSeleccionado,

  obtenerDireccion,

  barrioSeleccionado,
  setBarrioSeleccionado,

  mostrarBarrios,
  setMostrarBarrios,

  manejarEditarIntervencion,
  intervencionEnfocada,
  intervencionHoverId,

  modoDibujo,
  setModoDibujo,

  sidebarAbierto,
  manejarEnfocarIntervencion,

  assetsPanelAbierto,

  guideOverlay,
}) {
  return useMemo(
    () => ({
      form,
      setForm,

      intervencionesFiltradas,
      intervencionEditandoId,

      puntoSeleccionado,
      setPuntoSeleccionado,

      obtenerDireccion,

      barrioSeleccionado,
      setBarrioSeleccionado,

      mostrarBarrios,
      setMostrarBarrios,

      editarIntervencion:
        manejarEditarIntervencion,

      intervencionEnfocada,
      intervencionHoverId,

      modoDibujo,
      setModoDibujo,

      sidebarAbierto,

      enfocarIntervencion:
        manejarEnfocarIntervencion,

      assetsPanelAbierto,

      guideOverlay,
    }),
    [
      form,
      setForm,
      intervencionesFiltradas,
      intervencionEditandoId,
      puntoSeleccionado,
      setPuntoSeleccionado,
      obtenerDireccion,
      barrioSeleccionado,
      setBarrioSeleccionado,
      mostrarBarrios,
      setMostrarBarrios,
      manejarEditarIntervencion,
      intervencionEnfocada,
      intervencionHoverId,
      modoDibujo,
      setModoDibujo,
      sidebarAbierto,
      manejarEnfocarIntervencion,
      assetsPanelAbierto,
      guideOverlay,
    ]
  )
}